source_context_icons = [
    "⛔ not in context",
    "🟡 insights",
    "🟢 full content",
]

note_context_icons = [
    "⛔ not in context",
    "🟢 full content",
]
